from encrypt import encrypt
from decrypt import decrypt

encrypt()
decrypt()